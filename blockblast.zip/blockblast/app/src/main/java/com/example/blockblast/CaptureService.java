package com.example.blockblast;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class CaptureService extends Service {
    private WindowManager wm;
    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private int W, H, dpi;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private OverlayView overlay;
    private LinearLayout panel;
    private SharedPreferences prefs;
    private boolean showing = false;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int id) {
        NotificationChannel ch = new NotificationChannel("bb", "블록블라스트 도우미", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
        Notification n = new Notification.Builder(this, "bb").setContentTitle("블록블라스트 도우미 실행 중")
                .setSmallIcon(android.R.drawable.ic_menu_view).build();
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(1, n);

        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        W = dm.widthPixels; H = dm.heightPixels; dpi = dm.densityDpi;

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(in.getIntExtra("code", 0), in.getParcelableExtra("data"));
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopSelf(); }
        }, ui);
        reader = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 2);
        vd = projection.createVirtualDisplay("bb", W, H, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, null);
        buildUi();
        return START_NOT_STICKY;
    }

    private WindowManager.LayoutParams lp(boolean touchable, int w, int h) {
        int flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (!touchable) flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        return new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                flags, PixelFormat.TRANSLUCENT);
    }

    private void buildUi() {
        overlay = new OverlayView(this);
        WindowManager.LayoutParams full = lp(false, -1, -1);
        full.gravity = Gravity.TOP | Gravity.START;
        wm.addView(overlay, full);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0x88000000);
        Button analyze = btn("분석"), calib = btn("보정");
        analyze.setOnClickListener(v -> onAnalyze());
        calib.setOnClickListener(v -> startCalibration());
        panel.addView(analyze); panel.addView(calib);
        WindowManager.LayoutParams p = lp(true, -2, -2);
        p.gravity = Gravity.TOP | Gravity.END; p.x = 8; p.y = 300;
        wm.addView(panel, p);
    }

    private Button btn(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(14); b.setMinWidth(0); b.setMinimumWidth(0); return b;
    }

    // ---------- 보정: 터치 6번 ----------
    private void startCalibration() {
        overlay.clear(); showing = false;
        final String[] steps = {
                "① 판(8x8)의 왼쪽 위 모서리를 터치", "② 판의 오른쪽 아래 모서리를 터치",
                "③ 블록 3개가 놓인 영역의 왼쪽 위를 터치", "④ 그 영역의 오른쪽 아래를 터치",
                "⑤ 트레이 블록 '한 칸'의 왼쪽 위를 터치", "⑥ 같은 한 칸의 오른쪽 아래를 터치"};
        final float[] xs = new float[6], ys = new float[6];
        final int[] step = {0};
        final FrameLayoutHolder h = new FrameLayoutHolder();
        final TextView hint = new TextView(this);
        hint.setTextSize(22); hint.setTextColor(0xFFFFFFFF); hint.setBackgroundColor(0xCC000000);
        hint.setText(steps[0]); hint.setGravity(Gravity.CENTER); hint.setPadding(24, 120, 24, 24);
        hint.setOnTouchListener((v, e) -> {
            if (e.getAction() != MotionEvent.ACTION_DOWN) return true;
            xs[step[0]] = e.getRawX(); ys[step[0]] = e.getRawY(); step[0]++;
            if (step[0] == 6) {
                prefs.edit().putFloat("bx0", xs[0]).putFloat("by0", ys[0]).putFloat("bx1", xs[1]).putFloat("by1", ys[1])
                        .putFloat("tx0", xs[2]).putFloat("ty0", ys[2]).putFloat("tx1", xs[3]).putFloat("ty1", ys[3])
                        .putFloat("cell", Math.max(Math.abs(xs[5] - xs[4]), Math.abs(ys[5] - ys[4]))).apply();
                wm.removeView(hint);
            } else hint.setText(steps[step[0]]);
            return true;
        });
        wm.addView(hint, lp(true, -1, -1));
    }
    private static class FrameLayoutHolder {}

    private Vision.Cfg loadCfg() {
        if (!prefs.contains("cell")) return null;
        Vision.Cfg c = new Vision.Cfg();
        c.bx0 = prefs.getFloat("bx0", 0); c.by0 = prefs.getFloat("by0", 0);
        c.bx1 = prefs.getFloat("bx1", 0); c.by1 = prefs.getFloat("by1", 0);
        c.tx0 = prefs.getFloat("tx0", 0); c.ty0 = prefs.getFloat("ty0", 0);
        c.tx1 = prefs.getFloat("tx1", 0); c.ty1 = prefs.getFloat("ty1", 0);
        c.cell = prefs.getFloat("cell", 1);
        return c;
    }

    // ---------- 분석 ----------
    private void onAnalyze() {
        if (showing) { overlay.clear(); showing = false; }     // 두 번째 탭: 숨기기
        final Vision.Cfg cfg = loadCfg();
        if (cfg == null) { overlay.show(null, null, null, "먼저 [보정]을 해주세요"); ui.postDelayed(overlay::clear, 2000); return; }
        overlay.clear();
        ui.postDelayed(() -> grabAndSolve(cfg, 0), 250);        // 오버레이가 사라진 화면을 캡처
    }

    private void grabAndSolve(final Vision.Cfg cfg, final int tries) {
        Image img = reader.acquireLatestImage();
        if (img == null) {
            if (tries < 15) ui.postDelayed(() -> grabAndSolve(cfg, tries + 1), 100);
            return;
        }
        final int[] px = new int[W * H];
        try {
            Image.Plane pl = img.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int rowStride = pl.getRowStride(), pix = pl.getPixelStride();
            Bitmap bmp = Bitmap.createBitmap(rowStride / pix, H, Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(buf);
            bmp.getPixels(px, 0, W, 0, 0, W, H);
            bmp.recycle();
        } finally { img.close(); }

        new Thread(() -> {
            boolean[][] board = Vision.readBoard(px, W, H, cfg);
            Solver.Piece[] pcs = Vision.readPieces(px, W, H, cfg);
            Solver.Result r = Solver.solve(board, pcs);
            ui.post(() -> {
                if (r.moves.isEmpty()) overlay.show(cfg, pcs, null, "블록을 못 찾았어요 (보정 확인)");
                else overlay.show(cfg, pcs, r.moves, null);
                showing = !r.moves.isEmpty();
            });
        }).start();
    }

    @Override public void onDestroy() {
        try { if (overlay != null) wm.removeView(overlay); } catch (Exception ignored) {}
        try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) {}
        if (vd != null) vd.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        super.onDestroy();
    }
}
