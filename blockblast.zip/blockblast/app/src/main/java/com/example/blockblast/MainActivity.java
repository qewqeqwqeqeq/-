package com.example.blockblast;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 1;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 0);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(48, 48, 48, 48);
        TextView t = new TextView(this);
        t.setTextSize(16);
        t.setText("1) 다른 앱 위에 표시 권한 허용\n2) 시작 → 화면 캡처 허용\n3) 블록 블라스트를 켜고 [보정]을 눌러 점 6개를 터치(처음 한 번만)\n4) 이후 [분석]을 누르면 최적 위치가 번호로 표시돼요");
        root.addView(t);
        Button perm = new Button(this); perm.setText("1. 오버레이 권한");
        perm.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));
        Button start = new Button(this); start.setText("2. 시작");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()))); return; }
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(), REQ_CAPTURE);
        });
        Button stop = new Button(this); stop.setText("종료");
        stop.setOnClickListener(v -> stopService(new Intent(this, CaptureService.class)));
        root.addView(perm); root.addView(start); root.addView(stop);
        setContentView(root);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAPTURE && res == RESULT_OK && data != null) {
            Intent i = new Intent(this, CaptureService.class);
            i.putExtra("code", res); i.putExtra("data", data);
            startForegroundService(i);
            moveTaskToBack(true);
        }
    }
}
