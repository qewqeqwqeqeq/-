package com.example.blockblast;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import java.util.List;

/** 터치를 통과시키는 전체 화면 오버레이: 추천 위치를 번호와 색으로 표시. */
public class OverlayView extends View {
    private static final int[] COLORS = {0xAAFF3B30, 0xAA34C759, 0xAA0A84FF};
    private final Paint fill = new Paint(), text = new Paint(Paint.ANTI_ALIAS_FLAG), edge = new Paint();
    private Vision.Cfg cfg;
    private Solver.Piece[] pieces;
    private List<Solver.Move> moves;
    private String message;

    public OverlayView(Context c) {
        super(c);
        text.setColor(0xFFFFFFFF); text.setTextAlign(Paint.Align.CENTER); text.setFakeBoldText(true);
        text.setShadowLayer(4, 0, 0, 0xFF000000);
        edge.setStyle(Paint.Style.STROKE); edge.setStrokeWidth(5);
    }

    public void show(Vision.Cfg cfg, Solver.Piece[] pieces, List<Solver.Move> moves, String msg) {
        this.cfg = cfg; this.pieces = pieces; this.moves = moves; this.message = msg; invalidate();
    }

    public void clear() { moves = null; message = null; invalidate(); }

    @Override protected void onDraw(Canvas cv) {
        if (message != null) {
            text.setTextSize(48); cv.drawText(message, getWidth() / 2f, 200, text);
        }
        if (cfg == null || moves == null) return;
        float cw = (cfg.bx1 - cfg.bx0) / 8f, ch = (cfg.by1 - cfg.by0) / 8f;
        float zw = (cfg.tx1 - cfg.tx0) / 3f;
        for (int n = 0; n < moves.size(); n++) {
            Solver.Move m = moves.get(n);
            Solver.Piece p = pieces[m.slot];
            int col = COLORS[n % 3];
            fill.setColor(col); edge.setColor(col | 0xFF000000);
            text.setTextSize(Math.min(cw, ch) * 0.6f);
            for (int i = 0; i < p.h; i++) for (int j = 0; j < p.w; j++) {
                if (!p.shape[i][j]) continue;
                float x = cfg.bx0 + (m.c + j) * cw, y = cfg.by0 + (m.r + i) * ch;
                cv.drawRect(x + 3, y + 3, x + cw - 3, y + ch - 3, fill);
                cv.drawRect(x + 3, y + 3, x + cw - 3, y + ch - 3, edge);
                cv.drawText(String.valueOf(n + 1), x + cw / 2, y + ch / 2 + text.getTextSize() / 3, text);
            }
            // 트레이: 어느 블록을 몇 번째로 놓는지
            text.setTextSize(64);
            cv.drawText(String.valueOf(n + 1), cfg.tx0 + (m.slot + 0.5f) * zw, cfg.ty0 - 20, text);
        }
    }
}
