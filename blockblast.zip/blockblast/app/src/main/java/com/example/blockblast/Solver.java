package com.example.blockblast;

import java.util.ArrayList;
import java.util.List;

/** 8x8 판, 최대 3개 블록의 최적 배치(6가지 순서 x 모든 위치)를 비트마스크로 탐색. */
public final class Solver {
    public static final class Piece {
        public final boolean[][] shape;
        public final int h, w;
        public Piece(boolean[][] shape) {
            this.shape = shape; this.h = shape.length; this.w = shape[0].length;
        }
        long mask(int r, int c) {
            long m = 0;
            for (int i = 0; i < h; i++)
                for (int j = 0; j < w; j++)
                    if (shape[i][j]) m |= 1L << ((r + i) * 8 + (c + j));
            return m;
        }
    }

    public static final class Move {
        public final int slot, r, c;
        public Move(int slot, int r, int c) { this.slot = slot; this.r = r; this.c = c; }
    }

    public static final class Result {
        public List<Move> moves = new ArrayList<>();
        public double score = -1e18;
    }

    private static final long[] ROW = new long[8], COL = new long[8];
    static {
        for (int i = 0; i < 8; i++) { ROW[i] = 0xFFL << (8 * i); COL[i] = 0x0101010101010101L << i; }
    }

    public static long toMask(boolean[][] b) {
        long m = 0;
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) if (b[r][c]) m |= 1L << (r * 8 + c);
        return m;
    }

    /** pieces[i] 가 null 이면 이미 사용한 슬롯. */
    public static Result solve(boolean[][] board, Piece[] pieces) {
        int remaining = 0;
        for (int i = 0; i < pieces.length; i++) if (pieces[i] != null) remaining |= 1 << i;
        Result best = new Result();
        if (remaining == 0) return best;
        rec(toMask(board), pieces, remaining, 0, new int[9], 0, best);
        return best;
    }

    /** 남은 블록 중 하나를 골라 모든 위치에 놓아 보며 재귀 (순서까지 전부 탐색). */
    private static void rec(long board, Piece[] pcs, int remaining, int depth, int[] path, int lines, Result best) {
        if (remaining == 0) { record(best, board, lines, 0, path, depth); return; }
        boolean anyPlaced = false;
        for (int s = 0; s < pcs.length; s++) {
            if ((remaining & (1 << s)) == 0) continue;
            Piece p = pcs[s];
            for (int r = 0; r + p.h <= 8; r++) {
                for (int c = 0; c + p.w <= 8; c++) {
                    long m = p.mask(r, c);
                    if ((board & m) != 0) continue;
                    anyPlaced = true;
                    long nb = board | m, clr = 0; int ln = 0;
                    for (int i = 0; i < 8; i++) {
                        if ((nb & ROW[i]) == ROW[i]) { clr |= ROW[i]; ln++; }
                        if ((nb & COL[i]) == COL[i]) { clr |= COL[i]; ln++; }
                    }
                    path[depth * 3] = s; path[depth * 3 + 1] = r; path[depth * 3 + 2] = c;
                    rec(nb & ~clr, pcs, remaining & ~(1 << s), depth + 1, path, lines + ln, best);
                }
            }
        }
        if (!anyPlaced) record(best, board, lines, Integer.bitCount(remaining), path, depth);
    }

    private static void record(Result best, long board, int lines, int unplaced, int[] path, int n) {
        double s = evaluate(board, lines, unplaced);
        if (s > best.score) {
            best.score = s;
            best.moves = new ArrayList<>();
            for (int i = 0; i < n; i++) best.moves.add(new Move(path[i * 3], path[i * 3 + 1], path[i * 3 + 2]));
        }
    }

    static double evaluate(long b, int lines, int unplaced) {
        double s = 0;
        s += lines * 40 + (lines > 1 ? lines * lines * 12 : 0);
        s -= unplaced * 1000;
        s -= Long.bitCount(b) * 1.2;
        int holes = 0, trans = 0;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                boolean f = (b >>> (r * 8 + c) & 1) != 0;
                if (!f) {
                    int nb = 0;
                    nb += (r == 0 || (b >>> ((r - 1) * 8 + c) & 1) != 0) ? 1 : 0;
                    nb += (r == 7 || (b >>> ((r + 1) * 8 + c) & 1) != 0) ? 1 : 0;
                    nb += (c == 0 || (b >>> (r * 8 + c - 1) & 1) != 0) ? 1 : 0;
                    nb += (c == 7 || (b >>> (r * 8 + c + 1) & 1) != 0) ? 1 : 0;
                    if (nb >= 3) holes += (nb == 4 ? 3 : 1);
                }
                if (c < 7 && f != ((b >>> (r * 8 + c + 1) & 1) != 0)) trans++;
                if (r < 7 && f != ((b >>> ((r + 1) * 8 + c) & 1) != 0)) trans++;
            }
        }
        s -= holes * 6.0;
        s -= trans * 1.0;
        return s;
    }
}
