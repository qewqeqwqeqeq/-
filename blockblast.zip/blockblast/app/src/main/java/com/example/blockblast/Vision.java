package com.example.blockblast;

/** 스크린샷(ARGB int 배열)에서 판과 트레이의 블록을 읽는다. 안드로이드 의존성 없음. */
public final class Vision {
    public static final class Cfg {
        public float bx0, by0, bx1, by1;   // 8x8 판의 좌상단/우하단 (픽셀)
        public float tx0, ty0, tx1, ty1;   // 블록 3개가 놓인 트레이 영역
        public float cell;                  // 트레이 블록 한 칸의 한 변(픽셀)
    }

    // 채워진 칸 = 채도/명도가 높은 색. 빈 칸은 어두운 남색. 기기에서 안 맞으면 여기만 조정.
    static final float SAT_MIN = 0.35f, VAL_MIN = 0.45f;

    static boolean colored(int p) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        int max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        if (max == 0) return false;
        return (max - min) / (float) max > SAT_MIN && max / 255f > VAL_MIN;
    }

    static boolean filledAt(int[] px, int W, int H, float cx, float cy) {
        int r = 0, g = 0, b = 0, n = 0;
        for (int dy = -2; dy <= 2; dy++) for (int dx = -2; dx <= 2; dx++) {
            int x = (int) cx + dx, y = (int) cy + dy;
            if (x < 0 || y < 0 || x >= W || y >= H) continue;
            int p = px[y * W + x];
            r += (p >> 16) & 255; g += (p >> 8) & 255; b += p & 255; n++;
        }
        if (n == 0) return false;
        return colored(0xFF000000 | ((r / n) << 16) | ((g / n) << 8) | (b / n));
    }

    public static boolean[][] readBoard(int[] px, int W, int H, Cfg c) {
        boolean[][] out = new boolean[8][8];
        float cw = (c.bx1 - c.bx0) / 8f, ch = (c.by1 - c.by0) / 8f;
        for (int r = 0; r < 8; r++) for (int k = 0; k < 8; k++)
            out[r][k] = filledAt(px, W, H, c.bx0 + (k + 0.5f) * cw, c.by0 + (r + 0.5f) * ch);
        return out;
    }

    public static Solver.Piece readPiece(int[] px, int W, int H, Cfg c, int slot) {
        float zw = (c.tx1 - c.tx0) / 3f;
        int x0 = Math.max(0, (int) (c.tx0 + slot * zw)), x1 = Math.min(W - 1, (int) (c.tx0 + (slot + 1) * zw));
        int y0 = Math.max(0, (int) c.ty0), y1 = Math.min(H - 1, (int) c.ty1);
        int minx = Integer.MAX_VALUE, miny = Integer.MAX_VALUE, maxx = -1, maxy = -1, cnt = 0;
        for (int y = y0; y <= y1; y += 2) for (int x = x0; x <= x1; x += 2)
            if (colored(px[y * W + x])) {
                cnt++;
                if (x < minx) minx = x; if (x > maxx) maxx = x;
                if (y < miny) miny = y; if (y > maxy) maxy = y;
            }
        if (cnt < c.cell * c.cell / 8f) return null;
        float w = maxx - minx + 1, h = maxy - miny + 1;
        int n = Math.max(1, Math.min(5, Math.round(w / c.cell)));
        int m = Math.max(1, Math.min(5, Math.round(h / c.cell)));
        boolean[][] sh = new boolean[m][n];
        boolean any = false;
        for (int i = 0; i < m; i++) for (int j = 0; j < n; j++) {
            sh[i][j] = filledAt(px, W, H, minx + (j + 0.5f) * w / n, miny + (i + 0.5f) * h / m);
            any |= sh[i][j];
        }
        return any ? new Solver.Piece(sh) : null;
    }

    public static Solver.Piece[] readPieces(int[] px, int W, int H, Cfg c) {
        Solver.Piece[] out = new Solver.Piece[3];
        for (int i = 0; i < 3; i++) out[i] = readPiece(px, W, H, c, i);
        return out;
    }
}
