import com.example.blockblast.*;
import java.util.*;
public class Test {
  static void rect(int[] px,int W,int x,int y,int s,int col){for(int j=y;j<y+s;j++)for(int i=x;i<x+s;i++)px[j*W+i]=col;}
  public static void main(String[] a){
    int W=1080,H=2400; int[] px=new int[W*H]; Arrays.fill(px,0xFF1B2440);
    Vision.Cfg c=new Vision.Cfg(); c.bx0=60;c.by0=500;c.bx1=1020;c.by1=1460; float cw=120;
    // 판: 8x8 에 일부 채우기 (행 7 을 7칸 채워서 한 줄 완성 유도)
    boolean[][] want=new boolean[8][8];
    for(int k=0;k<7;k++)want[7][k]=true; want[6][0]=true; want[6][1]=true; want[3][3]=true;
    for(int r=0;r<8;r++)for(int k=0;k<8;k++)if(want[r][k])rect(px,W,(int)(60+k*cw+6),(int)(500+r*cw+6),108,0xFFE0402A);
    c.tx0=60;c.ty0=1650;c.tx1=1020;c.ty1=2150;c.cell=64;
    // 슬롯0: 1x1, 슬롯1: 2x2 ㄱ자 3칸, 슬롯2: 가로 3
    rect(px,W,60+150,1800,60,0xFF30B040);
    int bx=60+320+110, by=1780; rect(px,W,bx,by,60,0xFF3070E0);rect(px,W,bx+64,by,60,0xFF3070E0);rect(px,W,bx,by+64,60,0xFF3070E0);
    int cx=60+640+60; for(int i=0;i<3;i++)rect(px,W,cx+i*64,1800,60,0xFFE0C030);
    boolean[][] bd=Vision.readBoard(px,W,H,c);
    int diff=0;for(int r=0;r<8;r++)for(int k=0;k<8;k++)if(bd[r][k]!=want[r][k])diff++;
    System.out.println("board diff="+diff);
    Solver.Piece[] ps=Vision.readPieces(px,W,H,c);
    for(int i=0;i<3;i++)System.out.println("slot"+i+": "+(ps[i]==null?"null":ps[i].h+"x"+ps[i].w+" cells="+cnt(ps[i])));
    long t=System.nanoTime();
    Solver.Result r=Solver.solve(bd,ps);
    System.out.println("ms="+(System.nanoTime()-t)/1e6+" score="+r.score);
    for(Solver.Move m:r.moves)System.out.println("slot"+m.slot+" -> r"+m.r+" c"+m.c);
  }
  static int cnt(Solver.Piece p){int n=0;for(boolean[] r:p.shape)for(boolean b:r)if(b)n++;return n;}
}
